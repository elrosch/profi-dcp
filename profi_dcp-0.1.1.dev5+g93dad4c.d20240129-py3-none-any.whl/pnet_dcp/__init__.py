"""
Copyright (c) 2024 Elias Rosch, Esslingen.
Copyright (c) 2020 Codewerk GmbH, Karlsruhe.
All Rights Reserved.
"""
